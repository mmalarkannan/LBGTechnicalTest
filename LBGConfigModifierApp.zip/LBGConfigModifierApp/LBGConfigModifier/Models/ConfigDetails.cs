﻿using LBGConfigModifier.Utils;
using System.ComponentModel;
using System.Text;

namespace LBGConfigModifier.Models
{
    public class ConfigDetails
    {
        [DisplayName("Server Name")]
        public required string ServerName { get; set; }
        public string? StartingText { get; set; }
        public string? EndingText { get; set; }
        public string? Content { get; set; }
        public Dictionary<string, string>? KeyDetails { get; set; }
        public string? KeyDetailsString { get; set; }
        public string? Key { get; set; }
        public string? Value { get; set; }
        public string? ErrorMessage { get; set; }

        public void GenerateKeyDetailsIntoString()
        {
            StringBuilder stringBuilder = new StringBuilder();

            if (KeyDetails == null) return;

            foreach (var entry in KeyDetails)
            {
                stringBuilder.Append($"{entry.Key}: {entry.Value}, ");
            }

            // Remove the trailing comma and space
            KeyDetailsString = stringBuilder.ToString().TrimEnd(',');
        }

        public Dictionary<string, string> GenerateKeyDetailsIntoDictionary()
        {
            Dictionary<string, string> keyDetails = new Dictionary<string, string>();
            if (KeyDetailsString == null) return keyDetails;

            // Split the string into key-value pairs
            string[] keyValuePairs = KeyDetailsString.Split(new[] { ", " }, StringSplitOptions.RemoveEmptyEntries);

            // Create a dictionary from the key-value pairs
            keyDetails = keyValuePairs
                .Select(pair => pair.Split(new[] { ": " }, StringSplitOptions.None))
                .ToDictionary(split => split[0], split => split[1]);
            
            return keyDetails;
        }

        public void UpdateContent()
        {
            if (KeyDetails == null)
            {
                return;
            }

            Content = string.Empty;
            int counter = 1;
            string strCRLF = Constants.CarriageReturnLineFeed;
            foreach (KeyValuePair<string, string> keyDet in KeyDetails)
            {
                if (counter == KeyDetails.Count)
                {
                    strCRLF = string.Empty;
                }

                if (ServerName == Constants.Defaults)
                {
                    Content += $"{keyDet.Key}={keyDet.Value}{strCRLF}";
                }
                else
                {
                    Content += keyDet.Key + Constants.ServerNameDeclarationStart + ServerName + Constants.ServerNameDeclarationEnd + Constants.EqualTo + keyDet.Value + strCRLF;
                }

                counter++;
            }
        }
    }
}
