﻿using LBGConfigModifier.Utils;
using System.Text;

namespace LBGConfigModifier.Models
{
    public class ConfigDetailsCollection
    {
        public ConfigDetailsCollection() 
        {
            Configs = new List<ConfigDetails>();
            ErrorMessage = string.Empty;
        }

        public List<ConfigDetails> Configs { get; set; }

        public String? ErrorMessage { get; set; }

        public String SerializeConfigDetails()
        {
            if (Configs == null || Configs.Count <= 0)
            {
                return string.Empty;
            }

            StringBuilder strBuilder = new StringBuilder();
            int counter = 1;
            foreach (ConfigDetails configModel in Configs)
            {
                strBuilder.AppendLine(configModel.StartingText);
                strBuilder.AppendLine(configModel.Content);
                strBuilder.AppendLine(configModel.EndingText);
                if (counter != Configs.Count)
                {
                    strBuilder.AppendLine(string.Empty);
                }
                counter++;
            }

            return strBuilder.ToString();
        }

        public List<ConfigDetails> DeserializeConfigDetails(string[] fileContents)
        {
            StringBuilder sbContent = new StringBuilder();
            ConfigDetails configModel = new ConfigDetails { ServerName = string.Empty };
            Dictionary<string, string> dicKeyValues = new Dictionary<string, string>();

            foreach (string content in fileContents)
            {
                if (content.Trim() == string.Empty)
                {
                    continue;
                }

                if (content.StartsWith(Constants.EndText))
                {
                    //Bind all data into model
                    configModel.Content = sbContent.ToString().TrimEnd();
                    configModel.EndingText = content;
                    configModel.KeyDetails = dicKeyValues;
                    configModel.GenerateKeyDetailsIntoString();
                    Configs.Add(configModel);

                    //Initialize all objects here
                    configModel = new ConfigDetails { ServerName = string.Empty };
                    dicKeyValues = new Dictionary<string, string>();
                    sbContent = new StringBuilder();
                    continue;
                }

                if (content.StartsWith(Constants.StartText))
                {
                    configModel.ServerName = content.Replace(Constants.StartText, string.Empty).Trim();
                    configModel.StartingText = content;
                }
                else if (!content.StartsWith(Constants.CommentDeclaration))
                {
                    string[] strKeyValues = content.Split("=");
                    if (strKeyValues.Length > 0)
                    {
                        string strKey = strKeyValues[0];
                        if (strKey.Contains(Constants.ServerNameDeclarationStart) && strKey.Contains(Constants.ServerNameDeclarationEnd))
                        {
                            strKey = strKey.Replace(Constants.ServerNameDeclarationStart + configModel.ServerName + Constants.ServerNameDeclarationEnd, string.Empty);
                        }
                        dicKeyValues.Add(strKey, strKeyValues[1]);
                    }

                    sbContent.AppendLine(content);
                }
            }
            return Configs;
        }
    }
}
