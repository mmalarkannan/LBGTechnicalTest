﻿using LBGConfigModifier.Models;
using LBGConfigModifier.Service;
using LBGConfigModifier.Utils;
using Microsoft.AspNetCore.Mvc;

namespace LBGConfigModifier.Controllers
{
    public class ConfigController : Controller
    {
        private readonly IConfigService _configService;

        public ConfigController(IConfigService configService)
        {
            _configService = configService;
        }

        [HttpGet]
        public IActionResult DisplayConfig()
        {
            ConfigDetailsCollection configs = _configService.ReadConfig();
            return View(configs);
        }

        [HttpGet]
        public IActionResult EditConfig(ConfigDetails configDetails)
        {
            configDetails.KeyDetails = configDetails.GenerateKeyDetailsIntoDictionary();
            return View(configDetails);
        }

        [HttpPost]
        public IActionResult SaveConfig(ConfigDetails configDetails)
        {
            configDetails.ErrorMessage = _configService.UpdateConfig(configDetails);
            //Redirect to Edit Config page if there is any errors
            if (!string.IsNullOrEmpty(configDetails.ErrorMessage))
            {
                //Always generate to string from dictionary to transfer data from controller to page and vice versa
                configDetails.GenerateKeyDetailsIntoString();
                return RedirectToAction(Constants.Nav_EditConfig, configDetails);
            }
            return RedirectToAction(Constants.Nav_DisplayConfig);
        }

        [HttpGet]
        public IActionResult AddNewKey(ConfigDetails configDetails)
        {
            configDetails.KeyDetails = configDetails.GenerateKeyDetailsIntoDictionary();
            return View(configDetails);
        }

        [HttpPost]
        public ActionResult AddConfig(ConfigDetails configDetails)
        {
            configDetails.ErrorMessage = string.Empty;
            //Redirect to Add New Key page if there is any errors
            if (configDetails.KeyDetails == null ||
                    configDetails.Key == null ||
                    configDetails.Key == string.Empty ||
                    configDetails.Value == null)
                    
            {
                configDetails.ErrorMessage = "Enter value for Key text";
                
                //Always generate to string from dictionary to transfer data from controller to page and vice versa
                configDetails.GenerateKeyDetailsIntoString();
                return RedirectToAction(Constants.Nav_AddNewKey, configDetails);
            }

            //Redirect to Add New Key page if supplied key already present
            if (configDetails.KeyDetails.ContainsKey(configDetails.Key))
            {
                configDetails.ErrorMessage = "Key already exists";

                //Always generate to string from dictionary to transfer data from controller to page and vice versa
                configDetails.GenerateKeyDetailsIntoString();
                return RedirectToAction(Constants.Nav_AddNewKey, configDetails);
            }

            //Add new key values to current key details list
            configDetails.KeyDetails.Add(configDetails.Key, configDetails.Value);

            //Always generate to string from dictionary to transfer data from controller to page and vice versa
            configDetails.GenerateKeyDetailsIntoString();
            return RedirectToAction(Constants.Nav_EditConfig, configDetails);
        }

        [HttpGet]
        public IActionResult About()
        {
            return View();
        }
    }
}
