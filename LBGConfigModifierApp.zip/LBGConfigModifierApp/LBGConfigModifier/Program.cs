using LBGConfigModifier.Service;

var builder = WebApplication.CreateBuilder(args);

string? strPath = builder.Configuration.GetValue<string>("ConfigFilePath");
if (strPath == null) return;

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddScoped<IConfigService, ConfigService>(serviceProvider =>
{
    return new ConfigService(strPath.ToString());
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Config}/{action=DisplayConfig}");

app.Run();
