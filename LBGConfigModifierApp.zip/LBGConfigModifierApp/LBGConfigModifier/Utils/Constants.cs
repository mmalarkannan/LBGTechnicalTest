﻿namespace LBGConfigModifier.Utils
{
    public static class Constants
    {
        public const string StartText = ";START ";
        public const string EndText = ";END ";
        public const string CommentDeclaration = ";";
        public const string ServerNameDeclarationStart = "{";
        public const string ServerNameDeclarationEnd = "}";
        public const string EqualTo = "=";
        public const string CarriageReturnLineFeed = "\r\n";
        public const string Defaults = "DEFAULTS";
        public const string Nav_DisplayConfig = "DisplayConfig";
        public const string Nav_AddNewKey = "AddNewKey";
        public const string Nav_EditConfig = "EditConfig";
    }
}
