﻿using LBGConfigModifier.Models;

namespace LBGConfigModifier.Service
{
    public class ConfigService : IConfigService
    {
        private readonly string _filePath = string.Empty;

        public ConfigService(string filePath)
        {
            _filePath = filePath;
        }

        /// <summary>
        /// This method reads the config text file and return all the lines into a user defined object
        /// </summary>
        /// <returns>ConfigDetailsCollection</returns>
        public ConfigDetailsCollection ReadConfig()
        {
            ConfigDetailsCollection configs = new ConfigDetailsCollection();
            if (string.IsNullOrEmpty(_filePath))
            {
                configs.ErrorMessage = "File Name is blank";
                return configs;
            }
            else if (!File.Exists(_filePath))
            {
                configs.ErrorMessage = "File Name doesn't exists";
                return configs;
            }

            string[] fileContents = File.ReadAllLines(_filePath);
           
            configs.Configs = configs.DeserializeConfigDetails(fileContents);
            return configs;
        }

        /// <summary>
        /// This method updates the config text file's whole content again into same defined format
        /// </summary>
        /// <param name="configDetails"></param>
        /// <returns>Error Message</returns>
        public string UpdateConfig(ConfigDetails configDetails)
        {
            string errMsg = string.Empty;
            if (configDetails == null ||
                    configDetails.KeyDetails == null ||
                    configDetails.KeyDetails.Count <= 0)
            {
                errMsg = "Given parameter doesn't have any values";
                return errMsg;
            }

            configDetails.UpdateContent();
            ConfigDetailsCollection configs = ReadConfig();
            if (!string.IsNullOrEmpty(configs.ErrorMessage))
            {
                return configs.ErrorMessage;
            }

            List<ConfigDetails> configModels = configs.Configs;

            int index = configModels.FindIndex(x => x.ServerName == configDetails.ServerName);
            if (index < 0)
            {
                errMsg = $"Server Name doesn't exist in config file - {configDetails.ServerName}";
                return errMsg;
            }

            configModels[index] = configDetails;
            configs = new ConfigDetailsCollection();
            configs.Configs = configModels;

            try
            {
                File.WriteAllText(_filePath, configs.SerializeConfigDetails());
            }
            catch (Exception ex)
            {
                errMsg = $"Unable to write into config file - {ex.Message}";
            }

            return errMsg;
        }

        public void DeleteConfig(ConfigDetails configModel)
        {
            //TO DO
        }
    }
}
