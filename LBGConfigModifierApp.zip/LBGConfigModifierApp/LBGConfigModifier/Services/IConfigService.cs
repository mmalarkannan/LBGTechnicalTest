﻿using LBGConfigModifier.Models;

namespace LBGConfigModifier.Service
{
    public interface IConfigService
    {
        ConfigDetailsCollection ReadConfig();

        string UpdateConfig(ConfigDetails configModel);
    }
}
