using LBGConfigModifier.Controllers;
using LBGConfigModifier.Models;
using LBGConfigModifier.Service;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace LBGUpdateConfigTests
{
    [TestClass]
    public class ConfigControllerTests
    {
        private IConfigService _configService;

        [TestInitialize]
        public void TestInitialize()
        {
            IConfiguration configuration = new ConfigurationBuilder()
               .AddJsonFile("appsettings.Development.json")
               .Build();

            string? strPath = configuration.GetValue<string>("ConfigFilePath");

            if (strPath == null)
            {
                return;
            }

            _configService = new ConfigService(strPath.ToString());
        }

        [TestMethod]
        public void Test_DisplayConfig_ReturnsValues()
        {
            var controller = new ConfigController(_configService);
            ConfigDetails configModel = new ConfigDetails { ServerName = string.Empty };
            var result = controller.DisplayConfig();
            Assert.IsNotNull(result);

            var viewResult = result as ViewResult;
            Assert.IsNotNull(viewResult);
            Assert.IsInstanceOfType(viewResult.ViewData.Model, typeof(ConfigDetailsCollection));
            var configs = viewResult.ViewData.Model as ConfigDetailsCollection;
            Assert.IsNotNull(configs);
            Assert.IsNotNull(configs.Configs);
            Assert.IsTrue(configs.Configs.Count > 0);
        }

        [TestMethod]
        public void Test_EditConfig_ReturnsValuesIncludingKeyDetailsList()
        {
            var controller = new ConfigController(_configService);
            ConfigDetails configDetails = new ConfigDetails { ServerName = string.Empty };
            var result = controller.DisplayConfig();
            Assert.IsNotNull(result);

            var viewResult = result as ViewResult;
            Assert.IsNotNull(viewResult);
            Assert.IsInstanceOfType(viewResult.ViewData.Model, typeof(ConfigDetailsCollection));
            var configs = viewResult.ViewData.Model as ConfigDetailsCollection;
            Assert.IsNotNull(configs);
            Assert.IsNotNull(configs.Configs);
            Assert.IsTrue(configs.Configs.Count > 0);
            configDetails = configs.Configs[0];
            Assert.IsNotNull(configDetails);
            Assert.IsNotNull(configDetails.KeyDetails);                   
            int KeyDetailsCount = configDetails.KeyDetails.Count;

            //Remove key details from the object
            configDetails.KeyDetails = new Dictionary<string, string>();
            result = controller.EditConfig(configDetails);

            Assert.IsNotNull(result);

            viewResult = result as ViewResult;
            Assert.IsNotNull(viewResult);
            Assert.IsInstanceOfType(viewResult.ViewData.Model, typeof(ConfigDetails));
            var config = viewResult.ViewData.Model as ConfigDetails;
            Assert.IsNotNull(config);
            Assert.IsNotNull(config.KeyDetails);
            Assert.AreEqual(KeyDetailsCount, config.KeyDetails.Count);
        }

        [TestMethod]
        public void Test_SaveConfig_UpdatesDefaultSectionCorrectly()
        {
            var controller = new ConfigController(_configService);
            ConfigDetails configDetails= new ConfigDetails { ServerName = string.Empty };
            var result = controller.DisplayConfig();
            Assert.IsNotNull(result);

            var viewResult = result as ViewResult;
            Assert.IsNotNull(viewResult);
            Assert.IsInstanceOfType(viewResult.ViewData.Model, typeof(ConfigDetailsCollection));
            var configs = viewResult.ViewData.Model as ConfigDetailsCollection;
            Assert.IsNotNull(configs);
            Assert.IsNotNull(configs.Configs);
            Assert.IsTrue(configs.Configs.Count > 0);
            configDetails = configs.Configs[0];
            Assert.IsNotNull(configDetails);
            Assert.IsNotNull(configDetails.KeyDetails);            

            Random rnd = new Random();
            //Update first config value
            string keyValue = "APPDEVTEST" + rnd.Next().ToString();
            configDetails.KeyDetails[configDetails.KeyDetails.First().Key] = keyValue;

            result = controller.SaveConfig(configDetails);
            Assert.IsNotNull(result);
            
            result = controller.DisplayConfig();
            Assert.IsNotNull(result);

            viewResult = result as ViewResult;
            Assert.IsNotNull(viewResult);
            Assert.IsInstanceOfType(viewResult.ViewData.Model, typeof(ConfigDetailsCollection));
            configs = viewResult.ViewData.Model as ConfigDetailsCollection;
            Assert.IsNotNull(configs);
            Assert.IsNotNull(configs.Configs);
            Assert.IsTrue(configs.Configs.Count > 0);
            configDetails = configs.Configs[0];
            Assert.IsNotNull(configDetails);
            Assert.IsNotNull(configDetails.KeyDetails);
            Assert.IsTrue(configDetails.KeyDetails.Count > 0);
            Assert.AreEqual(keyValue, configDetails.KeyDetails[configDetails.KeyDetails.First().Key]);
        }

        [TestMethod]
        public void Test_SaveConfig_UpdatesNonDefaultSectionCorrectly()
        {
            var controller = new ConfigController(_configService);
            ConfigDetails configDetails = new ConfigDetails { ServerName = string.Empty };
            var result = controller.DisplayConfig();
            Assert.IsNotNull(result);

            var viewResult = result as ViewResult;
            Assert.IsNotNull(viewResult);
            Assert.IsInstanceOfType(viewResult.ViewData.Model, typeof(ConfigDetailsCollection));
            var configs = viewResult.ViewData.Model as ConfigDetailsCollection;
            Assert.IsNotNull(configs);
            Assert.IsNotNull(configs.Configs);
            Assert.IsTrue(configs.Configs.Count > 1);
            configDetails = configs.Configs[1];
            Assert.IsNotNull(configDetails);
            Assert.IsNotNull(configDetails.KeyDetails);
                  
            Random rnd = new Random();
            string keyValue = "APPDEVTEST" + rnd.Next().ToString();
            //Update first config value
            configDetails.KeyDetails[configDetails.KeyDetails.First().Key] = keyValue;

            result = controller.SaveConfig(configDetails);
            Assert.IsNotNull(result);

            result = controller.DisplayConfig();
            Assert.IsNotNull(result);

            viewResult = result as ViewResult;
            Assert.IsNotNull(viewResult);
            Assert.IsInstanceOfType(viewResult.ViewData.Model, typeof(ConfigDetailsCollection));
            configs = viewResult.ViewData.Model as ConfigDetailsCollection;
            Assert.IsNotNull(configs);
            Assert.IsNotNull(configs.Configs);
            Assert.IsTrue(configs.Configs.Count > 1);
            configDetails = configs.Configs[1];
            Assert.IsNotNull(configDetails);
            Assert.IsNotNull(configDetails.KeyDetails);
            Assert.IsTrue(configDetails.KeyDetails.Count > 0);
            Assert.AreEqual(keyValue, configDetails.KeyDetails[configDetails.KeyDetails.First().Key]);
        }

        [TestMethod]
        public void Test_SaveConfig_DisplayErrorMessageIfKeyDetailsIsBlank()
        {
            var controller = new ConfigController(_configService);
            ConfigDetails configDetails = new ConfigDetails { ServerName = string.Empty };
            var result = controller.DisplayConfig();
            Assert.IsNotNull(result);

            var viewResult = result as ViewResult;
            Assert.IsNotNull(viewResult);
            Assert.IsInstanceOfType(viewResult.ViewData.Model, typeof(ConfigDetailsCollection));
            var configs = viewResult.ViewData.Model as ConfigDetailsCollection;
            Assert.IsNotNull(configs);
            Assert.IsNotNull(configs.Configs);
            Assert.IsTrue(configs.Configs.Count > 0);
            configDetails = configs.Configs[0];
            Assert.IsNotNull(configDetails);
            configDetails.KeyDetails = null;
            result = controller.SaveConfig(configDetails);
            Assert.IsNotNull(result);

            var redirectToActionResult = result as RedirectToActionResult;
            Assert.IsNotNull(redirectToActionResult);
            var routeValuesFromRedirect = redirectToActionResult.RouteValues;
            Assert.IsNotNull(routeValuesFromRedirect);
            Assert.IsInstanceOfType(routeValuesFromRedirect["ErrorMessage"], typeof(string));
            Assert.IsTrue(routeValuesFromRedirect.ContainsKey("ErrorMessage"));
            var errMsg = routeValuesFromRedirect["ErrorMessage"] as string;
            Assert.AreEqual("Given parameter doesn't have any values", errMsg);
        }

        [TestMethod]
        public void Test_SaveConfig_DisplayErrorMessageIfServerNameDoesNotMatch()
        {
            var controller = new ConfigController(_configService);
            ConfigDetails configDetails = new ConfigDetails { ServerName = string.Empty };
            var result = controller.DisplayConfig();
            Assert.IsNotNull(result);

            var viewResult = result as ViewResult;
            Assert.IsNotNull(viewResult);
            Assert.IsInstanceOfType(viewResult.ViewData.Model, typeof(ConfigDetailsCollection));
            var configs = viewResult.ViewData.Model as ConfigDetailsCollection;
            Assert.IsNotNull(configs);
            Assert.IsNotNull(configs.Configs);
            Assert.IsTrue(configs.Configs.Count > 0);
            configDetails = configs.Configs[0];
            Assert.IsNotNull(configDetails);
            Assert.IsNotNull(configDetails.KeyDetails);
            //Passed randon server name
            configDetails.ServerName = "TestServer123";
            result = controller.SaveConfig(configDetails);
            Assert.IsNotNull(result);

            var redirectToActionResult = result as RedirectToActionResult;
            Assert.IsNotNull(redirectToActionResult);
            var routeValuesFromRedirect = redirectToActionResult.RouteValues;
            Assert.IsNotNull(routeValuesFromRedirect);
            Assert.IsInstanceOfType(routeValuesFromRedirect["ErrorMessage"], typeof(string));
            Assert.IsTrue(routeValuesFromRedirect.ContainsKey("ErrorMessage"));
            var errMsg = routeValuesFromRedirect["ErrorMessage"] as string;
            Assert.AreEqual($"Server Name doesn't exist in config file - {configDetails.ServerName}", errMsg);
        }

        [TestMethod]
        public void Test_AddNewKey_ReturnsValuesIncludingKeyDetailsList()
        {
            var controller = new ConfigController(_configService);
            ConfigDetails configDetails = new ConfigDetails { ServerName = string.Empty };
            var result = controller.DisplayConfig();
            Assert.IsNotNull(result);

            var viewResult = result as ViewResult;
            Assert.IsNotNull(viewResult);
            Assert.IsInstanceOfType(viewResult.ViewData.Model, typeof(ConfigDetailsCollection));
            var configs = viewResult.ViewData.Model as ConfigDetailsCollection;
            Assert.IsNotNull(configs);
            Assert.IsNotNull(configs.Configs);
            Assert.IsTrue(configs.Configs.Count > 2);
            configDetails = configs.Configs[2];
            Assert.IsNotNull(configDetails);
            Assert.IsNotNull(configDetails.KeyDetails);
            int KeyDetailsCount = configDetails.KeyDetails.Count;

            //Remove key details from the object
            configDetails.KeyDetails = new Dictionary<string, string>();
            result = controller.AddNewKey(configDetails);

            Assert.IsNotNull(result);

            viewResult = result as ViewResult;
            Assert.IsNotNull(viewResult);
            Assert.IsInstanceOfType(viewResult.ViewData.Model, typeof(ConfigDetails));
            var config = viewResult.ViewData.Model as ConfigDetails;
            Assert.IsNotNull(config);
            Assert.IsNotNull(config.KeyDetails);
            Assert.AreEqual(KeyDetailsCount, config.KeyDetails.Count);
        }

        [TestMethod]
        public void Test_AddConfig_AddKeysCorrectly()
        {
            var controller = new ConfigController(_configService);
            ConfigDetails configDetails = new ConfigDetails { ServerName = string.Empty };
            var result = controller.DisplayConfig();
            Assert.IsNotNull(result);

            var viewResult = result as ViewResult;
            Assert.IsNotNull(viewResult);
            Assert.IsInstanceOfType(viewResult.ViewData.Model, typeof(ConfigDetailsCollection));
            var configs = viewResult.ViewData.Model as ConfigDetailsCollection;
            Assert.IsNotNull(configs);
            Assert.IsNotNull(configs.Configs);
            Assert.IsTrue(configs.Configs.Count > 2);
            configDetails = configs.Configs[2];
            Assert.IsNotNull(configDetails);
            Assert.IsNotNull(configDetails.KeyDetails);
            int KeyDetailsCount = configDetails.KeyDetails.Count;

            Random rnd = new Random();
            string keyName = "CONNECTION_STRING" + rnd.Next().ToString();
            string keyValue = "APPDEVTEST" + rnd.Next().ToString();
            configDetails.Key = keyName;
            configDetails.Value = keyValue;

            result = controller.AddConfig(configDetails);
            Assert.IsNotNull(result);

            var redirectToActionResult = result as RedirectToActionResult;
            Assert.IsNotNull(redirectToActionResult);
            var routeValuesFromRedirect = redirectToActionResult.RouteValues;
            Assert.IsNotNull(routeValuesFromRedirect);
            Assert.IsInstanceOfType(routeValuesFromRedirect["KeyDetails"], typeof(Dictionary<string,string>));
            Assert.IsTrue(routeValuesFromRedirect.ContainsKey("KeyDetails"));
            var keyDetails = routeValuesFromRedirect["KeyDetails"] as Dictionary<string, string>;
            Assert.IsNotNull(keyDetails);
            Assert.IsTrue(keyDetails.Count > 0);
            Assert.AreEqual(KeyDetailsCount + 1, keyDetails.Count);
            Assert.IsTrue(keyDetails.ContainsKey(keyName));
            Assert.AreEqual(keyValue, keyDetails[keyName]);
        }

        [TestMethod]
        public void Test_AddConfig_DisplayErrorMessageIfKeyIsBlank()
        {
            var controller = new ConfigController(_configService);
            ConfigDetails configDetails = new ConfigDetails { ServerName = string.Empty };
            var result = controller.DisplayConfig();
            Assert.IsNotNull(result);

            var viewResult = result as ViewResult;
            Assert.IsNotNull(viewResult);
            Assert.IsInstanceOfType(viewResult.ViewData.Model, typeof(ConfigDetailsCollection));
            var configs = viewResult.ViewData.Model as ConfigDetailsCollection;
            Assert.IsNotNull(configs);
            Assert.IsNotNull(configs.Configs);
            Assert.IsTrue(configs.Configs.Count > 2);
            configDetails = configs.Configs[2];
            Assert.IsNotNull(configDetails);
            Assert.IsNotNull(configDetails.KeyDetails);

            Random rnd = new Random();
            string keyName = String.Empty;
            string keyValue = "APPDEVTEST" + rnd.Next().ToString();
            configDetails.Key = keyName;
            configDetails.Value = keyValue;

            result = controller.AddConfig(configDetails);
            Assert.IsNotNull(result);

            var redirectToActionResult = result as RedirectToActionResult;
            Assert.IsNotNull(redirectToActionResult);
            var routeValuesFromRedirect = redirectToActionResult.RouteValues;
            Assert.IsNotNull(routeValuesFromRedirect);
            Assert.IsInstanceOfType(routeValuesFromRedirect["ErrorMessage"], typeof(string));
            Assert.IsTrue(routeValuesFromRedirect.ContainsKey("ErrorMessage"));
            var errMsg = routeValuesFromRedirect["ErrorMessage"] as string;
            Assert.AreEqual("Enter value for Key text", errMsg);
        }

        [TestMethod]
        public void Test_AddConfig_DisplayErrorMessageIfKeyAlreadyExists()
        {
            var controller = new ConfigController(_configService);
            ConfigDetails configDetails = new ConfigDetails { ServerName = string.Empty };
            var result = controller.DisplayConfig();
            Assert.IsNotNull(result);

            var viewResult = result as ViewResult;
            Assert.IsNotNull(viewResult);
            Assert.IsInstanceOfType(viewResult.ViewData.Model, typeof(ConfigDetailsCollection));
            var configs = viewResult.ViewData.Model as ConfigDetailsCollection;
            Assert.IsNotNull(configs);
            Assert.IsNotNull(configs.Configs);
            Assert.IsTrue(configs.Configs.Count > 0);
            configDetails = configs.Configs[0];
            Assert.IsNotNull(configDetails);
            Assert.IsNotNull(configDetails.KeyDetails);

            Random rnd = new Random();
            string keyName = "SERVER_NAME";
            string keyValue = "APPDEVTEST" + rnd.Next().ToString();
            configDetails.Key = keyName;
            configDetails.Value = keyValue;

            result = controller.AddConfig(configDetails);
            Assert.IsNotNull(result);

            var redirectToActionResult = result as RedirectToActionResult;
            Assert.IsNotNull(redirectToActionResult);
            var routeValuesFromRedirect = redirectToActionResult.RouteValues;
            Assert.IsNotNull(routeValuesFromRedirect);
            Assert.IsInstanceOfType(routeValuesFromRedirect["ErrorMessage"], typeof(string));
            Assert.IsTrue(routeValuesFromRedirect.ContainsKey("ErrorMessage"));
            var errMsg = routeValuesFromRedirect["ErrorMessage"] as string;
            Assert.AreEqual("Key already exists", errMsg);
        }
    }
}